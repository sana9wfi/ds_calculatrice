package com.example.ds_calculatrice;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class Historique extends CursorAdapter {

    public Historique(Context context, Cursor cursor, int flags) {
        super(context, cursor, flags);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.historique_item, parent, false);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        String equation = cursor.getString(cursor.getColumnIndexOrThrow("equation_txt"));
        String resultat = cursor.getString(cursor.getColumnIndexOrThrow("resultat"));

        TextView euation_txt = view.findViewById(R.id.calculView);
        TextView resultat_txt = view.findViewById(R.id.resultatView);

        euation_txt.setText(equation);
        resultat_txt.setText(resultat);
    }
}