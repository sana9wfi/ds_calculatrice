package com.example.ds_calculatrice;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase db;
    TextView calcul_view;
    TextView resultat_view;
    TextView resultatdb_View;
    TextView calculator_view;
    ListView  historique  ;
    String calcul = "";
    private View view;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTextViews();
        db = openOrCreateDatabase("calculator_sana", MODE_PRIVATE,null);
        db.execSQL("CREATE TABLE IF NOT EXISTS calculator_historique ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "equation_txt TEXT,"
                + "resultat TEXT)");
        displayLastHistoryEntry();


    }

    private void initTextViews()
    {

        calculator_view = (TextView)findViewById(R.id.calculView);
        resultatdb_View = (TextView)findViewById(R.id.resultatView);
        historique = (ListView) findViewById(R.id.historique);
        calcul_view = (TextView)findViewById(R.id.txt_calculer);
        resultat_view = (TextView)findViewById(R.id.txt_resultat);
    }

    private void setcalcul(String givenValue)
    {
        calcul = calcul + givenValue;
        calcul_view.setText(calcul);
    }


    public void egalOnClick(View view)
    {
        Double resultat = 0.0;
        try {
            if (calcul.endsWith("+") || calcul.endsWith("-") || calcul.endsWith("*") || calcul.endsWith("/")) {
                Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
                return;
            }
            if (calcul.equals("+") || calcul.equals("-") || calcul.equals("*")|| calcul.equals("*") ) {
                Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
                return;
            }

            if (calcul != "" && calcul != null){
                resultat = eval(calcul);
                ContentValues values = new ContentValues();
                values.put("equation_txt", calcul);
                values.put("resultat", resultat);
                db.insert("calculator_historique", null, values);
                displayLastHistoryEntry();
                if(resultat != null){
                    resultat_view.setText(String.valueOf(resultat.doubleValue()));
                    calcul = "";
                }
            }

        } catch (Exception e)
        {
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isNumeric(char c)
    {
        if((c <= '9' && c >= '0') || c == '.')
            return true;

        return false;
    }


    public void suppOnClick(View view)
    {
        calcul_view.setText("");
        calcul = "";
        resultat_view.setText("");
        leftBracket = true;
    }

    boolean leftBracket = true;

    public void backOnClick(View view)
    {
        this.view = view;

        String originalString = calcul_view.getText().toString();
        calcul = originalString.substring(0, originalString.length() - 1);
        calcul_view.setText(calcul);
    }


    public void divOnClick(View view)
    {
        if (calcul == "" || calcul == null) {
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
            return;
        }
        setcalcul("/");
    }

    public void septOnClick(View view)
    {
        setcalcul("7");
    }

    public void huitOnClick(View view)
    {
        setcalcul("8");
    }

    public void neufOnClick(View view)
    {
        setcalcul("9");
    }

    public void multiOnClick(View view)
    {
        if (calcul == "" || calcul == null) {
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
            return;
        }
        setcalcul("*");
    }

    public void quatreOnClick(View view)
    {
        setcalcul("4");
    }

    public void cinqOnClick(View view)
    {
        setcalcul("5");
    }

    public void sixOnClick(View view)
    {
        setcalcul("6");
    }

    public void moinOnClick(View view)
    {
        if (calcul == "" || calcul == null) {
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
            return;
        }
        setcalcul("-");
    }

    public void unOnClick(View view)
    {
        setcalcul("1");
    }

    public void deuxOnClick(View view)
    {
        setcalcul("2");
    }

    public void troisOnClick(View view)
    {
        setcalcul("3");
    }

    public void plusOnClick(View view)
    {
        if (calcul == "" || calcul == null) {
            Toast.makeText(this, "Invalid Input", Toast.LENGTH_SHORT).show();
            return;
        }
        setcalcul("+");
    }

    public void pointOnClick(View view)
    {
        setcalcul(".");
    }

    public void zeroOnClick(View view)
    {
        setcalcul("0");
    }
    private void displayLastHistoryEntry() {

        Cursor cursor = db.rawQuery("SELECT id AS _id, equation_txt, resultat  FROM calculator_historique ORDER BY id asc", null);
        if (cursor.moveToFirst()) {

            Historique adapter = new Historique(this, cursor, 0);
            historique.setAdapter(adapter);
            historique.setSelection(cursor.getCount() - 1);

        }

    }

    public static double eval(final String str) {
        return new Object() {
            int pos = -1, ch;
            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }
            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }
            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Unexpected:  " + (char)ch);
                return x;
            }
            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }
            double parseTerm() {
                double x = parseFactor();
                for (;;) {
                    if (eat('*')) x *= parseFactor();
                    else if (eat('/')) x /= parseFactor();
                    else return x;
                }
            }
            double parseFactor() {
                if (eat('+')) return +parseFactor();
                if (eat('-')) return -parseFactor();
                double x;
                int startPos = this.pos;
                if (eat('(')) {
                    x = parseExpression();
                    if (!eat(')')) throw new RuntimeException("Missing ')'");
                } else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                } else if (ch >= 'a' && ch <= 'z') {
                    while (ch >= 'a' && ch <= 'z') nextChar();
                    String func = str.substring(startPos, this.pos);
                    if (eat('(')) {
                        x = parseExpression();
                        if (!eat(')')) throw new RuntimeException("Missing ')'  after argument to " + func);
                    } else {
                        x = parseFactor();
                    }
                    if (func.equals("sqrt")) x = Math.sqrt(x);
                    else if (func.equals("sin")) x =
                            Math.sin(Math.toRadians(x));
                    else if (func.equals("cos")) x =
                            Math.cos(Math.toRadians(x));
                    else if (func.equals("tan")) x =
                            Math.tan(Math.toRadians(x));
                    else throw new RuntimeException("Unknown function: " +
                                func);
                } else {
                    throw new RuntimeException("Unexpected: " + (char)ch);
                }
                if (eat('^')) x = Math.pow(x, parseFactor());
                return x;
            }
        }.parse();
    }
}